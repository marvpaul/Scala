package main

/**
 * @author hendrik
 */
object Appi {
   def main(args: Array[String]) = {
     println("bummi")
   }
}