package loganalyse

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row
import java.time.{LocalDate, OffsetDateTime}
import java.time.format.DateTimeFormatter

object LogAnalyseFuns {
  
  def getParsedData(data:RDD[String]):(RDD[(Row,Int)],RDD[Row],RDD[Row])={
    
      val parsed_logs= data.map(Utilities.parse_line(_))
      val access_logs= parsed_logs.filter(_._2==1).map(_._1).cache()
      val failed_logs= parsed_logs.filter(_._2==0).map(_._1)
      (parsed_logs, access_logs, failed_logs)
  }
  
  def calculateLogStatistic(data:RDD[Row]):(Long,Long,Long)= {
      val numbers = data.map(row=>row.get(8).toString.toLong)
      (numbers.min, numbers.max, numbers.sum.toLong/numbers.count)
  }
  /* 
   * Calculate for the content size the following values:
   * 
   * minimum: Minimum value
   * maximum: Maximum value
   * average: Average
   * 
   * Return the following triple:
   * (min,max,avg)
   */

  
  
  def getResponseCodesAndFrequencies(data:RDD[Row]):List[(Int,Int)]= {
      //Get codes
	  val codes = data.map(row=>row.get(7).toString.toLong)

	  //Group by codes
      val groupedCodes = codes.groupBy(x=>x)

	  //Map to [(code, count)]
	  groupedCodes
		  .map(x=>(x._1.toInt, x._2.count(x=>true)))
		  .collect()
		  .toList
  }
  
  /* 
   * Calculate for each single response code the number of occurences
   * Return a list of tuples which contain the response code as the first
   * element and the number of occurences as the second.
   *    *   
   */
    
  
  def get20HostsAccessedMoreThan10Times(data:RDD[Row]):List[String]= {
	  //Get hosts grouped
	  val groupedHosts = data
		  .map(row=>row.get(0).toString)
		  .groupBy(x=>x)

	  //Filter hosts with more than 10 access and take 20
	  groupedHosts
		  .filter(x=>x._2.count(x=>true)>10)
		  .map(x=>x._1)
		  .take(20)
		  .toList
  }
  
  /* 
   * Calculate 20 abitrary hosts from which the web server was accessed more than 10 times 
   * Print out the result on the console (no tests take place)
   */
  
  def getTopTenEndpoints(data:RDD[Row]):List[(String, Int)]= {
	  val endpoints = data.map(row=>row.get(5).toString)
	  val endpointsGrouped = endpoints.groupBy(x=>x)
	  endpointsGrouped
		  .map(x=>(x._1, x._2.count(x=>true))) //Map to [(endpoint, nr_of_occurences)]
		  .sortBy(x=>x._2, ascending = false)
		  .take(10)
		  .toList
  }
  
  /* 
   * Calcuclate the top ten endpoints. 
   * Return a list of tuples which contain the path of the endpoint as the first element
   * and the number of accesses as the second
   * The list should be ordered by the number of accesses.
   */
      
  def getTopTenErrorEndpoints(data:RDD[Row]):List[(String, Int)]= {

	  //Get endpoints and error codes
	  val endpointsAndCodes = data.map(row=>(row.get(5).toString, row.get(7).toString.toInt))
	  //Sth like (myEndpoint=>(myEndpoint, myEndpoint), myNewPoint=>(myNewPoint, myNewPoint, myNewPoint))

	  //Filter endpoints with non 200 code
	  val errorEndpointsGrouped = endpointsAndCodes.filter(x=> x._2 != 200).map(x=>x._1).groupBy(x=>x)

	  //Sort by most common endpoints / entries
	  errorEndpointsGrouped
		  .map(x=>(x._1, x._2.count(x=>true)))
		  .sortBy(x=>x._2, ascending = false)
		  .take(10)
		  .toList
  }
  
  /* 
   * Calculate the top ten endpoint that produces error response codes (response code != 200).
   * 
   * Return a list of tuples which contain the path of the endpoint as the first element
   * and the number of errors as the second.
   * The list should be ordered by the number of accesses.
   */
  
  def getNumberOfRequestsPerDay(data:RDD[Row]):List[(Int,Int)]= {

	  //Get dates
	  val dates = data.map(row=>row.get(3).toString)


	  dates
		  .groupBy(x=>x.split("-")(2).split("T")(0).toInt) //Group by day
		  .map(x=>(x._1, x._2.count(x=>true))) //Map to [(day, nrOfRequests)]
		  .sortByKey(ascending = true).collect.toList //sort
  }
  
  /* 
   * Calculate the number of requests per day.
   * Return a list of tuples which contain the day (1..30) as the first element and the number of
   * accesses as the second.
   * The list should be ordered by the day number.
   */
  
  def numberOfUniqueHosts(data:RDD[Row]):Long= {
	  data
		  .map(row=>row.get(0))
		  .distinct
		  .count
  }
  
  /* 
   * Calculate the number of hosts that accesses the web server in June 95.
   * Every hosts should only be counted once.
   */
      
  def numberOfUniqueDailyHosts(data:RDD[Row]):List[(Int,Int)]= {
	  //Get dates and hosts
	  val datesAndHosts = data.map(row=>(row.get(3).toString, row.get(0).toString))
	  datesAndHosts
		  //Group by day
		  .groupBy(x=>x._1.split("-")(2).split("T")(0).toInt)
		  //Filter each doubled hosts on a day
    	  .map(x=>(x._1, x._2.map(x=>x._2).toList.distinct.count(x=>true))) // [(day, nrOfUniqueHosts)]
		  .sortByKey(ascending = true)
		  .collect
		  .toList
  }
  
  /* 
   * Calculate the number of hosts per day that accesses the web server.
   * Every host should only be counted once per day.
   * Order the list by the day number.
   */
  
  def averageNrOfDailyRequestsPerHost(data:RDD[Row]):List[(Int,Int)]= {
	  //Get dates and hosts
	  val datesAndHosts = data.map(row=>(row.get(3).toString, row.get(0).toString))
	  datesAndHosts
		  //Group by day
		  .groupBy(x=>x._1.split("-")(2).split("T")(0).toInt)
    	  .map(x=>(x._1, {
		      //Nr of different hosts
		      val nrHosts = x._2.map(x=>x._2).toList.distinct.count(x=>true)
		      x._2.count(x=>true) / nrHosts
	      }))
    	  .sortByKey(ascending = true)
    	  .collect
    	  .toList
  }
  
  /*
   * Calculate the average number of requests per host for each single day.
   * Order the list by the day number.
   */

  def top25ErrorCodeResponseHosts(data:RDD[Row]):Set[(String,Int)]= {
	  //Get hosts and codes
	  val hostsAndCodes = data.map(row=>(row.get(0).toString, row.get(7).toString.toInt))
	  //Filter by error code 404
	  val hostsWithErrorCodes = hostsAndCodes.filter(x=>x._2==404).map(x=>x._1)
	  hostsWithErrorCodes
		  .groupBy(x=>x) //Group by host names
    	  .map(x=>(x._1, x._2.count(x=>true))) //map [(host, nrOfErrors)]
    	  .sortBy(x=>x._2, ascending = false) //Sort
    	  .take(25)
    	  .toSet
  }

    /*
     * Calculate the top 25 hosts that causes error codes (Response Code=404)
     * Return a set of tuples consisting the hostnames  and the number of requests
     */
  
  def responseErrorCodesPerDay(data:RDD[Row]):List[(Int,Int)]= {
	  //Get dates and codes
	  val datesAndCodes = data.map(row=>(row.get(3).toString, row.get(7).toString.toInt))
	  //Filter error codes
	  val datesWithErrorCode = datesAndCodes.filter(x=>x._2==404).map(x=>x._1)
	  datesWithErrorCode
		  //Group by day
		  .groupBy(x=>x.split("-")(2).split("T")(0).toInt)
    	  .map(x=>(x._1, x._2.count(x=>true))) // Map [(day, nrOfErrors)]
    	  .sortByKey(ascending = true)
    	  .collect
    	  .toList
  }
  
  /*
   * Calculate the number of error codes (Response Code=404) per day.
   * Return a list of tuples that contain the day as the first element and the number as the second. 
   * Order the list by the day number.
   */
  
  def errorResponseCodeByHour(data:RDD[Row]):List[(Int,Int)]= {
	  //Get dates and codes
	  val datesAndCodes = data.map(row=>(row.get(3).toString, row.get(7).toString.toInt))

	  //Filter error codes
	  val datesWithErrorCode = datesAndCodes.filter(x=>x._2==404).map(x=>x._1)
	  datesWithErrorCode
		  //Group by hour
		  .groupBy(x=>x.split("T")(1).split(":")(0).toInt)
		  .map(x=>(x._1, x._2.count(x=>true))) //Map [(hour, nrOfErrors)]
		  .sortByKey(ascending = true)
		  .collect
		  .toList
  }
  
  /*
   * Calculate the error response coded for every hour of the day.
   * Return a list of tuples that contain the hour as the first element (0..23) abd the number of error codes as the second.
   * Ergebnis soll eine Liste von Tupeln sein, deren erstes Element die Stunde bestimmt (0..23) und 
   * Order the list by the hour-number.
   */

  
  def getAvgRequestsPerWeekDay(data:RDD[Row]):List[(Int,String)]= {
	  //Get dates
	  val dates = data.map(row=>row.get(3).toString)

	  //Map to [(dayOfWeek, date)]
	  val daysOfWeekAndDate = dates.map(x=>(getDayOfWeek(x.split("T")(0)), x.split("T")(0)))
	  val dayOfWeeksGroupedWithCount = daysOfWeekAndDate.groupBy(x=>x._1).map(x=>({

		  //Count occurences of a certain week day
		  val nrOfWeekday = x._2.toList.distinct.count(x=>true)
		  x._2.toList.count(x=>true) / nrOfWeekday //Divide by occurence of a certain weekday to get average count
	  }, x._1))

	  dayOfWeeksGroupedWithCount
    	  .collect
    	  .toList
  }
  
  /*
   * Calculate the number of requests per weekday (Monday, Tuesday,...).
   * Return a list of tuples that contain the number of requests as the first element and the weekday
   * (String) as the second.
   * The elements should have the following order: [Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday].
   */

	def getDayOfWeek(date:String):String = {
		val df = DateTimeFormatter.ofPattern("yyyy-MM-dd")
		LocalDate.parse(date,df).getDayOfWeek.name().toLowerCase.capitalize
	}
}
